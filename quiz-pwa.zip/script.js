// Código do quiz (idêntico ao fornecido por você, omitido aqui por espaço)
// Mantém a lógica das fases, renderização e interação